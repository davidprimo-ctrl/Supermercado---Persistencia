package datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mundo.Proveedor;



public class ServicioProveedor {

    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;


    
    
    public static boolean existeIdProveedor(int idProveedor) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery(
                        "SELECT ID_PROVEEDOR FROM PROVEEDOR WHERE ID_PROVEEDOR = " + idProveedor);
                boolean existe = rs.next();
                conn.close();
                return existe;
            }
        } catch (Exception ex) {
            System.out.println("Error existeIdProveedor: " + ex);
        }
        return false;
    }


    
    public static boolean guardarProveedor(Proveedor p) {
        if (existeIdProveedor(p.getIdProveedor())) {
            return false;
        }
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                String sql = "INSERT INTO PROVEEDOR (ID_PROVEEDOR, NOMBRE_PROVEEDOR, TELEFONO, ES_NACIONAL, ESTADO) VALUES ("
                        + p.getIdProveedor() + ", '"
                        + p.getNombreProveedor() + "', "
                        + p.getTelefono() + ", '"
                        + (p.isEsNacional() ? "S" : "N") + "', '"
                        + p.getEstado() + "')";
                stmt.executeUpdate(sql);
                conn.close();
                return true;
            }
        } catch (Exception ex) {
            System.out.println("Error guardarProveedor: " + ex);
        }
        return false;
    }


    
    public static List<Proveedor> getProveedores() {
        List<Proveedor> proveedores = new ArrayList<>();
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT * FROM PROVEEDOR");
                while (rs.next()) {
                    int id           = rs.getInt("ID_PROVEEDOR");
                    String nombre    = rs.getString("NOMBRE_PROVEEDOR");
                    double telefono  = rs.getDouble("TELEFONO");
                    boolean nacional = rs.getString("ES_NACIONAL").equals("S");
                    String estado    = rs.getString("ESTADO");
                    proveedores.add(new Proveedor(id, nombre, telefono, nacional, estado));
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error getProveedores: " + ex);
        }
        return proveedores;
    }


    
    
    public static Proveedor buscarProveedor(int idBuscado) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery(
                        "SELECT * FROM PROVEEDOR WHERE ID_PROVEEDOR = " + idBuscado);
                if (rs.next()) {
                    Proveedor p = new Proveedor(
                            rs.getInt("ID_PROVEEDOR"),
                            rs.getString("NOMBRE_PROVEEDOR"),
                            rs.getDouble("TELEFONO"),
                            rs.getString("ES_NACIONAL").equals("S"),
                            rs.getString("ESTADO")
                    );
                    conn.close();
                    return p;
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error buscarProveedor: " + ex);
        }
        return null;
    }


    
    public static boolean eliminarProveedor(int idBuscado) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                int filas = stmt.executeUpdate(
                        "UPDATE PROVEEDOR SET ESTADO = 'Inactivo' WHERE ID_PROVEEDOR = " + idBuscado);
                conn.close();
                return filas > 0;
            }
        } catch (Exception ex) {
            System.out.println("Error eliminarProveedor: " + ex);
        }
        return false;
    }


    
    public static boolean actualizarProveedor(Proveedor prov) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                String sql = "UPDATE PROVEEDOR SET "
                        + "NOMBRE_PROVEEDOR = '" + prov.getNombreProveedor() + "', "
                        + "TELEFONO = " + prov.getTelefono() + ", "
                        + "ES_NACIONAL = '" + (prov.isEsNacional() ? "S" : "N") + "'"
                        + " WHERE ID_PROVEEDOR = " + prov.getIdProveedor();
                int filas = stmt.executeUpdate(sql);
                conn.close();
                return filas > 0;
            }
        } catch (Exception ex) {
            System.out.println("Error actualizarProveedor: " + ex);
        }
        return false;
    }
}
