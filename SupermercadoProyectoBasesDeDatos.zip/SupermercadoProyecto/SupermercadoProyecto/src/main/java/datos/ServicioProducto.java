package datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mundo.Producto;


public class ServicioProducto {

    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;

    
    public static boolean existeCodigo(int codigo) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT CODIGO FROM PRODUCTO WHERE CODIGO = " + codigo);
                boolean existe = rs.next();
                conn.close();
                return existe;
            }
        } catch (Exception ex) {
            System.out.println("Error existeCodigo: " + ex);
        }
        return false;
    }

    
    
    public static boolean guardarProducto(Producto p) {
        if (!ServicioProveedor.existeIdProveedor(p.getIdProveedor())) {
            return false;
        }
        if (existeCodigo(p.getCodigo())) {
            return false;
        }
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                String sql = "INSERT INTO PRODUCTO (CODIGO, NOMBRE, PRECIO, PERECEDERO, ID_PROVEEDOR, ESTADO) VALUES ("
                        + p.getCodigo() + ", '"
                        + p.getNombre() + "', "
                        + p.getPrecio() + ", '"
                        + (p.isPerecedero() ? "S" : "N") + "', "
                        + p.getIdProveedor() + ", '"
                        + p.getEstado() + "')";
                stmt.executeUpdate(sql);
                conn.close();
                return true;
            }
        } catch (Exception ex) {
            System.out.println("Error guardarProducto: " + ex);
        }
        return false;
    }

    
    public static List<Producto> getProductos() {
        List<Producto> productos = new ArrayList<>();
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT * FROM PRODUCTO");
                while (rs.next()) {
                    int codigo = rs.getInt("CODIGO");
                    String nombre = rs.getString("NOMBRE");
                    double precio = rs.getDouble("PRECIO");
                    boolean peced = rs.getString("PERECEDERO").equals("S");
                    int idProv = rs.getInt("ID_PROVEEDOR");
                    String estado = rs.getString("ESTADO");
                    productos.add(new Producto(codigo, nombre, precio, peced, idProv, estado));
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error getProductos: " + ex);
        }
        return productos;
    }

    
    
    public static Producto buscarProducto(int codigoBuscado) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT * FROM PRODUCTO WHERE CODIGO = " + codigoBuscado);
                if (rs.next()) {
                    Producto p = new Producto(
                            rs.getInt("CODIGO"),
                            rs.getString("NOMBRE"),
                            rs.getDouble("PRECIO"),
                            rs.getString("PERECEDERO").equals("S"),
                            rs.getInt("ID_PROVEEDOR"),
                            rs.getString("ESTADO")
                    );
                    conn.close();
                    return p;
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error buscarProducto: " + ex);
        }
        return null;
    }


    
    public static boolean eliminarProducto(int codigoBuscado) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                int filas = stmt.executeUpdate(
                        "UPDATE PRODUCTO SET ESTADO = 'Inactivo' WHERE CODIGO = " + codigoBuscado);
                conn.close();
                return filas > 0;
            }
        } catch (Exception ex) {
            System.out.println("Error eliminarProducto: " + ex);
        }
        return false;
    }


    
    public static boolean actualizarProducto(Producto prod) {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                String sql = "UPDATE PRODUCTO SET "
                        + "NOMBRE = '" + prod.getNombre() + "', "
                        + "PRECIO = " + prod.getPrecio() + ", "
                        + "PERECEDERO = '" + (prod.isPerecedero() ? "S" : "N") + "', "
                        + "ID_PROVEEDOR = " + prod.getIdProveedor()
                        + " WHERE CODIGO = " + prod.getCodigo();
                int filas = stmt.executeUpdate(sql);
                conn.close();
                return filas > 0;
            }
        } catch (Exception ex) {
            System.out.println("Error actualizarProducto: " + ex);
        }
        return false;
    }

    
    
    public static double calcularSuma() {
        double sumatoria = 0;
        try {
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery(
                        "SELECT SUM(PRECIO) AS TOTAL FROM PRODUCTO WHERE ESTADO = 'Activo'");
                if (rs.next()) {
                    sumatoria = rs.getDouble("TOTAL");
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error calcularSuma: " + ex);
        }
        return sumatoria;
    }
}
