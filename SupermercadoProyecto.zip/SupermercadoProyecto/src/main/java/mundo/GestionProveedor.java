/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static mundo.Tienda.existeCodigo;

/**
 *
 * @author USUARIO
 */
public class GestionProveedor {
    private static final int TAM_NOMBRE = 30;
    private static final int TAM_ESTADO = 10;
    
    public static boolean existeIdProveedor(int idProveedor) {
        try {
            RandomAccessFile file = new RandomAccessFile("data//Proveedores.txt", "r");
            while (file.getFilePointer() < file.length()) {
                int id = file.readInt();
                file.readUTF();
                file.readDouble();
                file.readBoolean();
                file.readUTF();
                if (id == idProveedor) {
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch (Exception ex) {
        }
        return false;
    }
    
    public static boolean guardarEnArchivo(Proveedor p) {
        if (existeIdProveedor(p.getIdProveedor())) {
            return false;
        }
        try {
            RandomAccessFile file = new RandomAccessFile("data//Proveedores.txt", "rw");
            file.seek(file.length());
            file.writeInt(p.getIdProveedor());
            file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", p.getNombreProveedor()).substring(0, TAM_NOMBRE));
            file.writeDouble(p.getTelefono());
            file.writeBoolean(p.isEsNacional());
            file.writeUTF(String.format("%-" + TAM_ESTADO + "s", p.getEstado()).substring(0, TAM_ESTADO));
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
    
    public static List<Proveedor> getProveedores() {
        int idProveedor;
        String nombreProveedor;
        double telefono;
        boolean esNacional;
        String estado;
        
        List<Proveedor> proveedores = new ArrayList<>();

        try {
            RandomAccessFile file = new RandomAccessFile("data//Proveedores.txt", "r");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                idProveedor = file.readInt();
                nombreProveedor = file.readUTF().trim();
                telefono = file.readDouble();
                esNacional = file.readBoolean();
                estado = file.readUTF();

                Proveedor p = new Proveedor(idProveedor, nombreProveedor, telefono, esNacional, estado);
                proveedores.add(p);
            }
            file.close();

        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return proveedores;
    }
    
    public static Proveedor buscarProveedor(int idBuscado) {
        int idProveedor;
        String nombreProveedor;
        double telefono;
        boolean esNacional;
        String estado;
        
        try {
            RandomAccessFile file = new RandomAccessFile("data//Proveedores.txt", "r");
            while (file.getFilePointer() < file.length()) {
                idProveedor = file.readInt();
                nombreProveedor = file.readUTF();
                telefono = file.readDouble();
                esNacional = file.readBoolean();
                estado = file.readUTF();

                if (idProveedor == idBuscado) {
                    file.close();
                    return new Proveedor(idProveedor, nombreProveedor, telefono, esNacional, estado);
                }
            }
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public static boolean eliminarProveedor(int idBuscado) {
        long posicionInicio;
        int idProveedor;
        String nombreProveedor;
        double telefono;
        boolean esNacional;
        String estado;
        
        try {
        RandomAccessFile file = new RandomAccessFile("data//Proveedores.txt", "rw");
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            posicionInicio = file.getFilePointer();
            idProveedor = file.readInt();
            nombreProveedor = file.readUTF();       
            telefono = file.readDouble();    
            esNacional = file.readBoolean();
            estado = file.readUTF();

            if (idProveedor == idBuscado) {
                file.seek(posicionInicio);
                file.writeInt(idProveedor);
                file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", nombreProveedor).substring(0, TAM_NOMBRE));
                file.writeDouble(telefono);
                file.writeBoolean(esNacional);
                file.writeUTF(String.format("%-" + TAM_ESTADO + "s", "Inactivo").substring(0, TAM_ESTADO));
                file.close();
                return true;
            }
        }
        file.close();
    } catch (Exception ex) {
        Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
    }
    return false;
    }
    
    public static boolean actualizarProveedores (Proveedor prov){
        long posicionInicio;
        int idProveedor;
        String nombreProveedor;
        double telefono;
        boolean esNacional;
        String estado;
        
       
        try {
            RandomAccessFile file = new RandomAccessFile("data//Proveedores.txt", "rw");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                posicionInicio = file.getFilePointer();
                idProveedor = file.readInt();
                nombreProveedor = file.readUTF();
                telefono = file.readDouble();
                esNacional = file.readBoolean();
                estado = file.readUTF().trim();
                if (idProveedor == prov.getIdProveedor()) {
                    file.seek(posicionInicio);
                    file.writeInt(prov.getIdProveedor());
                    file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", prov.getNombreProveedor()).substring(0, TAM_NOMBRE));
                    file.writeDouble(prov.getTelefono());
                    file.writeBoolean(prov.isEsNacional());
                    file.writeUTF(String.format("%-" + TAM_ESTADO + "s", estado).substring(0, TAM_ESTADO));
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(GestionProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
