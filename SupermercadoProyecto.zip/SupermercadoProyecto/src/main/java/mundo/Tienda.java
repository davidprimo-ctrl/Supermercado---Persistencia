/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.io.RandomAccessFile;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class Tienda {
    private static final int TAM_NOMBRE = 30;
    private static final int TAM_ESTADO = 10;
    
    


    public static boolean existeCodigo(int codigo) {
        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
            while (file.getFilePointer() < file.length()) {
                int cod = file.readInt();
                file.readUTF();
                file.readDouble();
                file.readBoolean();
                file.readInt();
                file.readUTF();
                if (cod == codigo) {
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch (Exception ex) {
        }
        return false;
    }

    public static boolean guardarEnArchivo(Producto p) {
        if (!GestionProveedor.existeIdProveedor(p.getIdProveedor())) {
            return false;
        }
        if (existeCodigo(p.getCodigo())){
            return false;
        }
        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "rw");
            file.seek(file.length());
            file.writeInt(p.getCodigo());
            file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", p.getNombre()).substring(0, TAM_NOMBRE));
            file.writeDouble(p.getPrecio());
            file.writeBoolean(p.isPerecedero());
            file.writeInt(p.getIdProveedor());
            file.writeUTF(String.format("%-" + TAM_ESTADO + "s", p.getEstado()).substring(0, TAM_ESTADO));
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public static List<Producto> getProductos() {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        int idProveedor;
        String estado;
        
        List<Producto> productos = new ArrayList<>();

        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                codigo = file.readInt();
                nombre = file.readUTF().trim();
                precio = file.readDouble();
                perecedero = file.readBoolean();
                idProveedor = file.readInt();
                estado = file.readUTF();

                Producto p = new Producto(codigo, nombre, precio, perecedero, idProveedor, estado);
                productos.add(p);
            }
            file.close();

        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productos;
    }

    public static Producto buscarProducto(int codigoBuscado) {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        int idProveedor;
        String estado;
        
        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
            while (file.getFilePointer() < file.length()) {
                codigo = file.readInt();
                nombre = file.readUTF();
                precio = file.readDouble();
                perecedero = file.readBoolean();
                idProveedor = file.readInt();
                estado = file.readUTF();

                if (codigo == codigoBuscado) {
                    file.close();
                    return new Producto(codigo, nombre, precio, perecedero, idProveedor, estado);
                }
            }
            file.close();
        } catch (Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public static boolean eliminarProducto(int codigoBuscado) {
        long posicionInicio;
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        int idProveedor;
        String estado;
        
        try {
        RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "rw");
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            posicionInicio = file.getFilePointer();
            codigo = file.readInt();
            nombre = file.readUTF();       
            precio = file.readDouble();    
            perecedero = file.readBoolean();
            idProveedor = file.readInt();
            estado = file.readUTF();

            if (codigo == codigoBuscado) {
                file.seek(posicionInicio);
                file.readInt();
                file.readUTF();
                file.readDouble();
                file.readBoolean();
                file.readInt();
                file.writeUTF(String.format("%-" + TAM_ESTADO + "s", "Inactivo").substring(0, TAM_ESTADO));
                file.close();
                return true;
            }
        }
        file.close();
    } catch (Exception ex) {
        Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
    }
    return false;
}
    
    
    public static boolean actualizarProductos (Producto prod){
        long posicionInicio;
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        int idProveedor;
        String estado;
       
        try{
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "rw");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                posicionInicio = file.getFilePointer();
                codigo = file.readInt();
                nombre = file.readUTF();
                precio = file.readDouble();
                perecedero = file.readBoolean();
                idProveedor = file.readInt();
                estado = file.readUTF();
                
                if (codigo == prod.getCodigo()){
                    file.seek(posicionInicio);
                    file.writeInt(prod.getCodigo());
                    file.writeUTF(String.format("%-" + TAM_NOMBRE + "s", prod.getNombre()).substring(0, TAM_NOMBRE));
                    file.writeDouble(prod.getPrecio());
                    file.writeBoolean(prod.isPerecedero());
                    file.writeInt(prod.getIdProveedor());
                    file.writeUTF(String.format("%-" + TAM_ESTADO + "s", estado).substring(0, TAM_ESTADO));
                    file.close();
                    return true;
                }
            }
            file.close();
        } catch (Exception ex){
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    

    public static double calcularSuma() {
        int codigo;
        String nombre;
        double precio;
        boolean perecedero;
        int idProveedor;
        String estado;
        
        double sumatoria = 0;
        
        try {
            RandomAccessFile file = new RandomAccessFile("data//Productos.txt", "r");
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                codigo = file.readInt();
                nombre = file.readUTF();
                precio = file.readDouble();
                perecedero = file.readBoolean();
                idProveedor = file.readInt();
                estado = file.readUTF().trim();
            
                if (estado.equals("Activo")) {
                sumatoria += precio;
                }
            }
            file.close();
        } catch(Exception ex) {
            Logger.getLogger(Tienda.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sumatoria;
    }
}
